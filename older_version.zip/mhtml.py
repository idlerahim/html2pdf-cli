# requires: pip install playwright ; playwright install
from playwright.sync_api import sync_playwright
import sys, pathlib

mhtml = pathlib.Path(sys.argv[1]).resolve()
out = sys.argv[2] if len(sys.argv)>2 else "out.pdf"

with sync_playwright() as p:
    browser = p.chromium.launch()
    page = browser.new_page()
    page.goto("file://" + str(mhtml), wait_until="networkidle")
    height_px = page.evaluate("Math.max(document.documentElement.scrollHeight, document.body.scrollHeight)")
    height_in = height_px / 96
    page.pdf(path=out, width="8.5in", height=f"{height_in}in", print_background=True)
    browser.close()
    print("PDF written")
